package Entity;

import java.time.LocalDate;
import java.util.Scanner;
import Controller.Validation;
import Controller.QuanLyKhachHang;

public class Warranty {
    static Scanner sc = new Scanner(System.in);
    public Customer cus[] = QuanLyKhachHang.getListCustomer();
    private int flag; //cờ hiệu để tìm mã khách hàng (0 nếu không tìm thấy và 1 nếu tìm thấy. Được sử dụng trong hàm InputCustomer_ID, InputCustomerName, InputSDT)
    private String Product_ID;
    private LocalDate Product_Date;
    private String Years_Of_Warranty;
    private String Warranty_Method;
    private String Customer_ID;
    private String Customer_Name;
    private String SDT;

    public Warranty() {
        Product_ID = null;
        Product_Date = null;
        Years_Of_Warranty = null;
        Warranty_Method = null;
        Customer_ID = null;
        Customer_Name = null;
        SDT = null;
        flag = 0;
    }

    public Warranty(String product_ID, LocalDate product_Date, String years_Of_Warranty, String warranty_Method, String Customer_ID, String Customer_Name, String SDT) {
        this.Product_ID = product_ID;
        this.Product_Date = product_Date;
        this.Years_Of_Warranty = years_Of_Warranty;
        this.Warranty_Method = warranty_Method;
        this.Customer_ID = Customer_ID;
        this.Customer_Name = Customer_Name;
        this.SDT = SDT;
    }

    public String getProduct_ID() {
        return Product_ID;
    }

    public void setProduct_ID(String product_ID) {
        this.Product_ID = product_ID;
    }

    public LocalDate getProduct_Date() {
        return Product_Date;
    }

    public void setProduct_Date(LocalDate product_Date) {
        this.Product_Date = product_Date;
    }

    public String getYears_Of_Warranty() {
        return Years_Of_Warranty;
    }

    public void setYears_Of_Warranty(String years_Of_Warranty) {
        this.Years_Of_Warranty = years_Of_Warranty;
    }

    public String getWarranty_Method() {
        return Warranty_Method;
    }

    public void setWarranty_Method(String warranty_Method) {
        this.Warranty_Method = warranty_Method;
    }

    public String getCustomer_ID() {
        return Customer_ID;
    }

    public void setCustomer_ID(String customer_ID) {
        Customer_ID = customer_ID;
    }

    public String getCustomer_Name() {
        return Customer_Name;
    }

    public void setCustomer_Name(String customer_Name) {
        Customer_Name = customer_Name;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String sDT) {
        SDT = sDT;
    }


    //Hàm nhập data
    public void InputProduct_ID(Warranty warranty[]) {
        /*  Ràng buộc:
         *  Chuỗi không rỗng (Không có kí tự khoảng trắng)
         *  Chuỗi có độ dài không quá 6 VÀ id bắt đầu bằng kí tự sp
         */
        System.out.println("Nhập ID Sản phẩm (sp_) tối đa 6 kí tự: ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || (test.length() > 6 && !Validation.isIDProduct(test))) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("ID Sản phẩm không hợp lệ. Nhập lại: ");
            } else {
                setProduct_ID(test);
                int check = 0;
                for (Warranty w : warranty) {
                    if (getProduct_ID().equals(w.getProduct_ID())) {
                        check = 1;
                        break;
                    }
                }
                if (check == 1) {
                    System.out.println("\t\t\t\t\t\t\t\t +----MÃ SẢN PHẨM BỊ TRÙNG----+");
                } else {
                    break;
                }
            }
        }
    }
    public void InputProduct_Date(Warranty warranty[]) {
        /*  Ràng buộc:
         *  Chuỗi không rỗng (Không có kí tự khoảng trắng)
         *  Chuỗi có độ dài không quá 10
         *  Theo định dạng (yyyy'-'mm'-'dd'-')
         *  Năm từ 1000 -> 9999, Tháng từ 01 -> 12, Ngày từ 01 -> 31
         */
        System.out.println("Nhập Ngày sản xuất (yyyy-MM-dd): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || test.length() > 10) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Ngày không hợp lệ. Nhập lại: ");
            } else {
                if (Validation.isValidDate(test)) {
                    setProduct_Date(LocalDate.parse(test));
                    break;
                } else {
                    System.out.println("Ngày không hợp lệ. Nhập lại: ");
                }
            }
        }
    }
    public void InputYears_Of_Warranty(Warranty warranty[]) {
        /*  Ràng buộc:
         *  Phải là số nguyên
         *  Số năm bh từ 0 đến 5
         */
        System.out.println("Nhập số năm bảo hành (0 -> 5): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (!Validation.isInteger(test) || test.isBlank()) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Phải nhập số nguyên!. Nhập lại: ");
            } else {
                if (Integer.parseInt(test) < 0 || Integer.parseInt(test) > 5) {
                    System.out.println("Số năm bảo hành không hợp lệ");
                } else {
                    setYears_Of_Warranty(test);
                    break;
                }
            }
        }
    }
    public void InputWarranty_Method(Warranty warranty[]) {
        /*  Ràng buộc:
         *  Chuỗi không rỗng (Không có kí tự khoảng trắng)
         *  Chuỗi có độ dài không quá 20
         */
        System.out.println("Nhập Phương thức bảo hành (tối đa 20 kí tự): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || test.length() > 20) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Phương thức bảo hành không hợp lệ. Nhập lại: ");
            } else {
                setWarranty_Method(test);
                break;
            }
        }
    }
    public void InputCustomer_ID(Warranty warranty[]) {
        /*  Ràng buộc:
         *  Chuỗi không rỗng (Không có kí tự khoảng trắng)
         *  Chuỗi có độ dài không quá 6 VÀ id bắt đầu bằng kí tự kh
         */
        System.out.println("Nhập ID Khách hàng (kh_) tối đa 6 kí tự: ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || (test.length() > 6 && !Validation.isIDCustomer(test))) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("ID Khách hàng không hợp lệ. Nhập lại: ");
            } else {
                setCustomer_ID(test);
                for (Customer c : cus) {
                    if (c.getCustomer_ID().equals(test)) {
                        flag = 1;
                        break;
                    }
                    flag = 0;
                }
                break;
            }
        }
    }
    public void InputCustomer_Name(Warranty warranty[]) {
        /*  Ràng buộc:
         *  Chuỗi không rỗng (Không có kí tự khoảng trắng)
         *  Chuỗi có độ dài từ 10 đến 20 kí tự
         */

        if (flag == 1) {
            for (Customer c : cus) {
                if (getCustomer_ID().equals(c.getCustomer_ID())) {
                    setCustomer_Name(c.getName());
                    break;
                }
            }
        }
        else {
            System.out.println("Nhập tên Khách hàng (10 - 20 kí tự): ");
            String test;

            while (true) {
                test = sc.nextLine();
                if (test.isBlank() || (test.length() < 10 || test.length() > 20)) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                    System.out.println("Tên khách hàng không hợp lệ. Nhập lại: ");
                } else {
                    setCustomer_Name(test);
                    break;
                }
            }
        }
    }
    public void InputSDT(Warranty warranty[]) {
        /*  Ràng buộc:
         *  Chuỗi không rỗng (Không có kí tự khoảng trắng)
         *  Chuỗi có độ dài không quá 10
         *  Số 0 đứng đầu, 9 số kế tiếp
         *  Không có kí tự đặc biệt/chuỗi kí tự
         */

        if (flag == 1) {
            for (Customer c : cus) {
                if (getCustomer_ID().equals(c.getCustomer_ID())) {
                    setSDT(c.getSDT());
                    break;
                }
            }
        }
        else {
            System.out.println("Nhập SĐT Khách hàng: ");
            String test;
           
            while (true) {
                test = sc.nextLine();
                if (test.isBlank()) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                    System.out.println("SĐT không hợp lệ. Nhập lại: ");
                } else {
                    if (Validation.isValidPhoneNumber(test)) {
                        setSDT(test);
                        break;
                    } else {
                        System.out.println("SĐT không hợp lệ. Nhập lại");
                    }
                }
            }
        }
    }
}
