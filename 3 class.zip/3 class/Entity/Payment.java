package Entity;

import java.time.LocalDate;
import java.util.Scanner;

import Controller.Validation;


public class Payment {
    public int n;
    public String Payment_ID;
    public String Customer_ID;
    public String ID_Receipt;
    public String Amount;
    public LocalDate Payment_Date;
    public String Payment_Method;
    public String Status;
    Scanner sc = new Scanner(System.in);
    Payment[] payment;

    /* CONSTRUCTOR ************************************************************************************* */

    public Payment() {
        Payment_ID = null;
        Customer_ID = null;
        ID_Receipt = null;
        Amount = null;
        Payment_Date = null;
        Payment_Method = null;
        Status = null;
    }

    public Payment(String payment_ID, String customer_ID, String ID_Receipt, String amount, LocalDate payment_Date,
                   String payment_Method, String status) {
        this.Payment_ID = payment_ID;
        this.Customer_ID = customer_ID;
        this.ID_Receipt = ID_Receipt;
        this.Amount = amount;
        this.Payment_Date = payment_Date;
        this.Payment_Method = payment_Method;
        this.Status = status;
    }

    /* GETTER ****************************************************************************************** */

    public String getPayment_ID() {
        return Payment_ID;
    }

    public void setPayment_ID(String payment_ID) {
        this.Payment_ID = payment_ID;
    }

    public String getCustomer_ID() {
        return Customer_ID;
    }

    public void setCustomer_ID(String customer_ID) {
        this.Customer_ID = customer_ID;
    }

    public String getID_Receipt() {
        return ID_Receipt;
    }

    public void setID_Receipt(String ID_Receipt) {
        this.ID_Receipt = ID_Receipt;
    }

    public String getAmount() {
        return Amount;
    }

    /* SETTER ****************************************************************************************** */

    public void setAmount(String amount) {
        this.Amount = amount;
    }

    public LocalDate getPayment_Date() {
        return Payment_Date;
    }

    public void setPayment_Date(LocalDate payment_Date) {
        this.Payment_Date = payment_Date;
    }

    public String getPayment_Method() {
        return Payment_Method;
    }

    public void setPayment_Method(String payment_Method) {
        this.Payment_Method = payment_Method;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        this.Status = status;
    }


    //Hàm nhập data
    public void InputPayment_ID(Payment payment[]) {
        System.out.println("Nhập mã thanh toán (tt_) tối đa 6 kí tự: ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || (test.length() > 6 && !Validation.isIDPayment(test))) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Mã thanh toán không hợp lệ. Nhập lại: ");
            } else {
                setPayment_ID(test);
                int check = 0;
                for (Payment p : payment) {
                    if (getPayment_ID().equals(p.getPayment_ID())) {
                        check = 1;
                        break;
                    }
                }
                if (check == 1) {
                    System.out.println("\t\t\t\t\t\t\t\t +----MÃ THANH TOÁN BỊ TRÙNG----+");
                } else {
                    break;
                }
            }
        }
    }
    public void InputCustomer_ID(Payment payment[]) {
        System.out.println("Nhập mã khách hàng (kh_) tối đa 6 kí tự: ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || (test.length() > 6 && !Validation.isIDCustomer(test))) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Mã khách hàng không hợp lệ. Nhập lại: ");
            } else {
                setCustomer_ID(test);
                int check = 0;
                for (Payment p : payment) {
                    if (getCustomer_ID().equals(p.getCustomer_ID())) {
                        check = 1;
                        break;
                    }
                }
                if (check == 1) {
                    System.out.println("\t\t\t\t\t\t\t\t +----MÃ KHÁCH HÀNG BỊ TRÙNG----+");
                } else {
                    break;
                }
            }
        }
    }
    public void InputID_Receipt(Payment payment[]) {
        System.out.println("Nhập mã đơn hàng (hd_) tối đa 6 kí tự: ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || (test.length() > 6 && !Validation.isIDReceipt(test))) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Mã đơn hàng không được để trống. Nhập lại: ");
            } else {
                setID_Receipt(test);
                int check = 0;
                for (Payment p : payment) {
                    if (getID_Receipt().equals(p.getID_Receipt())) {
                        check = 1;
                        break;
                    }
                }
                if (check == 1) {
                    System.out.println("\t\t\t\t\t\t\t\t +----MÃ ĐƠN HÀNG BỊ TRÙNG----+");
                } else {
                    break;
                }
            }
        }
    }
    public void InputAmount(Payment payment[]) {
        System.out.println("Nhập số lượng hàng: ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank()) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Số lượng hàng không được để trống. Nhập lại: ");
            } else {
                setAmount(test);
                break;
            }
        }
    }
    public void InputPayment_Date(Payment payment[]) {
        System.out.println("Nhập ngày đặt hàng (yyyy-MM-dd): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || test.length() > 10) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Ngày đặt hàng không hợp lệ. Nhập lại: ");
            } else {
                if (Validation.isValidDate(test)) {
                    setPayment_Date(LocalDate.parse(test));
                    break;
                } else {
                    System.out.println("Ngày không hợp lệ. Nhập lại: ");
                }
            }
        }
    }
    public void InputPayment_Method(Payment payment[]) {
        System.out.println("Nhập phương thức thanh toán (không quá 20 kí tự): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || test.length() > 20) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Phương thức thanh toán không hợp lệ. Nhập lại: ");
            } else {
                setPayment_Method(test);
                break;
            }
        }
    }
    public void InputStatus(Payment payment[]) {
        System.out.println("Nhập trạng thái của đơn hàng (0 hoặc 1): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank()) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Trạng thái không được để trống. Nhập lại: ");
            } else {
                if (test.compareTo("0") == 0 || test.compareTo("1") == 0) {
                    setStatus(test);
                    break;
                }
                else {
                    System.out.println("Trạng thái không hợp lệ. Nhập lại: ");
                }
            }
        }
    }
}
