package Entity;

import java.util.Scanner;

import Controller.Validation;


public class Manager extends Person {
    static Scanner sc = new Scanner(System.in);
    protected String ID_Manager;
    protected String Role;
    protected String Shift;

    public Manager(String ID_Manager, String name, Integer age, String gender, String address, String email, String SDT, String role, String shift) {
        super(name, age, gender, address, email, SDT);
        this.ID_Manager = ID_Manager;
        this.Role = role;
        this.Shift = shift;
    }

    public Manager() {
        super();
        ID_Manager = null;
        Role = null;
        Shift = null;
    }

    public Manager(String ID_Manager, String role, String shift, int SLNVQL) {
        this.ID_Manager = ID_Manager;
        this.Role = role;
        this.Shift = shift;
    }

    public String getID_Manager() {
        return ID_Manager;
    }

    public void setID_Manager(String ID_Manager) {
        this.ID_Manager = ID_Manager;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }

    public String getShift() {
        return Shift;
    }

    public void setShift(String shift) {
        Shift = shift;
    }


    //Hàm nhập data
    public void InputID_Manager(Manager manager[]) {
        System.out.println("Nhập ID người quản lý (ql_): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || (test.length() > 6 && !Validation.isIDManager(test))) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Mã người quản lý không được để trống. Nhập lại: ");
            } else {
                setID_Manager(test);
                int check = 0;
                for (Manager m : manager) {
                    if (getID_Manager().equals(m.getID_Manager())) {
                        check = 1;
                        break;
                    }
                }
                if (check == 1) {
                    System.out.println("\t\t\t\t\t\t\t\t +-----MÃ NGƯỜI QUẢN LÝ BỊ TRÙNG-----+");
                } else {
                    break;
                }
            }
        }
    }
    public void InputRole(Manager manager[]) {
        System.out.println("Nhập Chức vụ (không quá 20 kí tự): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || test.length() > 20) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Chức vụ không hợp lệ. Nhập lại: ");
            } else {
                setRole(test);
                break;
            }
        }
    }
    public void InputShift(Manager manager[]) {
        System.out.println("Nhập Ca trực (không quá 10 kí tự): ");
        String test;

        while (true) {
            test = sc.nextLine();
            if (test.isBlank() || test.length() > 10) {   //nếu như xâu test rỗng hoặc chứa toàn khoảng trắng, NHẬP LẠI ĐEEEEEEEE!!!!
                System.out.println("Ca trực không hợp lệ. Nhập lại: ");
            } else {
                setShift(test);
                break;
            }
        }
    }
    public void AddThongTin() {
        super.AddThongTin();
    }
}