package Controller;

//thư viện để check lỗi
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class Validation {
    //Regex cho ID
    public static boolean isIDProduct(String input) {
        String regex = "^sp\\d+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();
    }


    public static boolean isIDCustomer(String input) {
        String regex = "^kh\\d+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();
    }


    public static boolean isIDReceipt(String input) {
        String regex = "^hd\\d+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();
    }


    public static boolean isIDPayment(String input) {
        String regex = "^tt\\d+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();
    }


    public static boolean isIDManager(String input) {
        String regex = "^ql\\d+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();
    }

    //Regex cho Logic
    public static boolean isValidDate(String inputDate) {
        String dateFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        sdf.setLenient(false);

        try {
            Date date = sdf.parse(inputDate);
            // Kiểm tra giá trị của ngày và tháng
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);

            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH) + 1; // Tháng bắt đầu từ 0
            int day = cal.get(Calendar.DAY_OF_MONTH);

            // Kiểm tra giá trị của năm, tháng và ngày
            if (year >= 1000 && year <= 9999 && month >= 1 && month <= 12 && day >= 1 && day <= cal.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                return true;
            }
        } catch (ParseException e) {
            // Nếu có ngoại lệ ParseException, chuỗi không hợp lệ
            return false;
        }

        return false;
    }


    public static boolean isValidPhoneNumber(String phoneNumber) {
        String regex = "^0\\d{9}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
    }


    public static boolean isInteger(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
